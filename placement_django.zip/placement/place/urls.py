from . import  views
from django.urls import path

urlpatterns=[
    path('home',views.home,name='home'),
    path('register',views.register,name='register'),
    path('login',views.login,name='login'),
    path('',views.login,name='login'),
    path('about',views.about,name='about'),
    path('contact',views.contact,name='contact'),
    path('aptitude',views.aptitude,name='aptitude'),
    path('tech',views.tech,name='tech'),
    #path('group',views.group,name='group')
    path('admin_login',views.admin_login,name='admin_login'),
    path('admin_menu',views.admin_menu,name='admin_menu'),
    path('users_list',views.users_list,name='users_list'),
    path('quiz_list',views.quiz_list,name='quiz_list'),
    path('add_question',views.add_question,name='add_question'),
    path('add_quiz',views.add_quiz,name='add_quiz'),
    path('question_list',views.question_list,name='question_list'),
    path('admin_quiz_list',views.admin_quiz_list,name='admin_quiz_list'),
    path('question',views.question,name='question'),
    path('developer',views.developer,name='developer'),
    path('delete_quiz',views.delete_quiz,name='delete_quiz'),
    path('edit_quiz',views.edit_quiz,name='edit_quiz'),
    path('edit_details',views.edit_details,name='edit_details'),
    path('feedback',views.feedback,name='feedback'),
    path('rev_list',views.rev_list,name='rev_list')



]