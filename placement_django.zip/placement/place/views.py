import datetime
import random

from django.shortcuts import render, redirect
from django.contrib.auth.models import User, auth
from django.contrib import messages
from place.models import questions, review,quiz
import smtplib


# Create your views here.
def home(request):
    obj=review.objects.all()
    l1=list(obj)
    obj1=l1[:3]
    print(obj1)
    return render(request, 'home.html',{'list':obj1})


def about(request):
    return render(request, 'about.html')


def aptitude(request):
    obj=questions.objects.filter(category='Aptitude')
    return render(request, 'aptitude.html',{'apti':obj})


def question(request):
    if request.method=='POST':
        type=request.POST['type']
        category=request.POST['category']
        obj=questions.objects.filter(category=category,type=type)
        return render(request,'question.html',{'data':obj})

def contact(request):
    if request.method == 'POST':
        name = request.POST['name']
        email = request.POST['email']
        ph = request.POST['phone']
        msg = request.POST['message']
        try:
            s = smtplib.SMTP('smtp.gmail.com', 587)
            s.starttls()
            s.login("bharathsr2001@gmail.com", "Bharath@B26")
            message = "Contact \n\nName : {}\nEmail : {}\nTelephone : {}\n{}".format(name, email, ph, msg)
            s.sendmail(email, "bharathsr2001@gmail.com", message)
            s.quit()
            messages.success(request, 'Successfully Sent')
            print('Sent')
            return redirect('contact')
        except:
            messages.success(request, 'Unable to sent !!!')
            print('Unable to sent')
            return redirect('contact')
    else:
        return render(request, 'contact.html')


def tech(request):
    obj = questions.objects.filter(category='Technical')
    return render(request, 'tech.html', {'tech': obj})


def register(request):
    if request.method == 'POST':
        first_name = request.POST['fname']
        last_name = request.POST['lname']
        email = request.POST['email']
        username = request.POST['username']
        password = request.POST['password']
        if User.objects.filter(username=username).exists():
            messages.error(request, 'Username exists')
        elif User.objects.filter(email=email).exists():
            messages.error(request, 'Email is already exist.')
        elif len(password) < 8:
            messages.error(request, 'Password length should be 8 or more.')
        else:
            user = User.objects.create_user(first_name=first_name, last_name=last_name, email=email, username=username,
                                            password=password)
            user.save()
            messages.success(request, 'User is created successfully.')
            return redirect('home')
    else:
        return render(request, 'register.html')


def login(request):
    if request.method == "POST":
        username = request.POST['username']
        password = request.POST['password']
        user = auth.authenticate(username=username, password=password)
        if user is not None:
            auth.login(request, user)

            messages.success(request, 'Welcome ' + username)
            return redirect('home')
        else:
            messages.success(request, "Username or Password is not exist")
            return redirect('login')
    else:
        return render(request, 'login.html')


def admin_login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['pass']
        if username == 'prepskills' and password == 'prepskills.com':
            return redirect('admin_menu')
        else:
            messages.success(request, 'Username or Password is wrong !!!')
            return redirect('admin_login')
    else:
        return render(request, 'admin_login.html')


def admin_menu(request):
    obj = questions.objects.all()
    l1 = len(list(obj))
    obj1 = User.objects.exclude(username='prepskills')
    l2 = len(list(obj1))
    obj2 = review.objects.all()
    l3 = len(list(obj2))
    obj4=quiz.objects.all()
    l4=len(list(obj4))
    return render(request, 'admin_menu.html', {'qn': l1, 'user': l2, 'rev': l3,'quiz':l4})


def users_list(request):
    obj=User.objects.exclude(username='prepskills')
    count=1
    return render(request,'users_list.html',{'data':obj,'count':count})

def quiz_list(request):
    obj=quiz.objects.filter(category='Aptitude')
    obj1=quiz.objects.filter(category='Technical')
    return render(request,'quiz_list.html',{'list':obj,'tlist':obj1})

def add_question(request):
    if request.method=='POST':
        category=request.POST['category']
        type=request.POST['type']
        question=request.POST['question']
        answer=request.POST['answer']
        exp=request.POST['exp']
        qid=random.randint(100,100000)
        obj1=questions(qn_id=qid,category=category,type=type,qun=question,answer=answer,explanation=exp)
        obj1.save()
        messages.success(request,'Question is added successfully !!!')
        return redirect('question_list')
    else:
        return render(request,'add_question.html')

def question_list(request):
    obj =questions.objects.filter(category='Aptitude')
    obj1 = questions.objects.filter(category='Technical')
    count=0
    return render(request, 'question_list.html', {'list': obj, 'tlist': obj1,'count':count})


def add_quiz(request):
    if request.method=='POST':
        category=request.POST['category']
        title=request.POST['title']
        url=request.POST['url']
        qid=random.randint(100,100000)
        obj=quiz(qid=qid,category=category,title=title,url=url)
        obj.save()
        return redirect('admin_quiz_list')
    else:
        return render(request,'add_quiz.html')

def delete_quiz(request):
    if request.method=='POST':
        quiz_id=request.POST['quiz_id']
        obj=quiz.objects.get(qid=quiz_id)
        obj.delete()
        messages.success(request,'Deleted Successfully!!')
        return redirect('admin_quiz_list')


def edit_quiz(request):
    if request.method=='POST':
        quiz_id=request.POST['quiz_id']
        obj=quiz.objects.get(qid=quiz_id)
        return render(request,'edit_quiz.html',{'data':obj})

def edit_details(request):
    if request.method=='POST':
        quiz_id=request.POST['quiz_id']
        category=request.POST['category']
        title=request.POST['title']
        url=request.POST['url']
        obj=quiz.objects.get(qid=quiz_id)
        obj.category=category
        obj.title=title
        obj.url=url
        obj.save()
        messages.success(request,'Successfully Changed!!!')
        return redirect('admin_quiz_list')

def admin_quiz_list(request):
    obj = quiz.objects.filter(category='Aptitude')
    obj1 = quiz.objects.filter(category='Technical')
    return render(request, 'admin_quiz_list.html', {'list': obj, 'tlist': obj1})


def developer(request):
    return render(request, 'developer.html')


def feedback(request):
    if request.method=='POST':
        rating=request.POST['feedback']
        opinion=request.POST['msg']
        name=request.POST['name']
        designation=request.POST['designation']
        rev_id=random.randint(100,10000)
        now=datetime.datetime.now()
        obj=review(rev_id=rev_id,rating=rating,statement=opinion,rev_by=name,designation=designation,time=now)
        obj.save()
        messages.success(request,'Thank you for your feedback !!')
        return redirect('home')


def rev_list(request):
    obj=review.objects.all()
    return render(request,'rev_list.html',{'list':obj})