import datetime

from django.db import models as mo


class questions(mo.Model):
    qn_id = mo.CharField(max_length=5, default='', primary_key=True)
    category=mo.CharField(max_length=15,default='')
    type=mo.CharField(max_length=25,default='')
    qun = mo.TextField(max_length=100, default='')
    answer = mo.TextField(max_length=15, default='')
    explanation = mo.TextField(max_length=250, default='')


    def __str__(self):
        return self.qn_id


class review(mo.Model):
    rev_id = mo.CharField(max_length=10, default='', primary_key=True)
    rating=mo.CharField(max_length=10,default='')
    statement = mo.TextField(max_length=100, default='')
    rev_by = mo.CharField(default='', max_length=20)
    designation = mo.CharField(default='', max_length=20)
    time=mo.DateTimeField(default=datetime.datetime.now())

    def __str__(self):
        return self.rev_id


class quiz(mo.Model):
    qid=mo.CharField(max_length=10,default='',primary_key=True)
    category=mo.CharField(max_length=15,default='')
    title=mo.TextField(max_length=30,default='')
    url=mo.URLField(verbose_name=None)

    def __str__(self):
        return self.qid
