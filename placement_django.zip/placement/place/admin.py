from django.contrib import admin
from place.models import questions,review,quiz

admin.site.register(questions)
admin.site.register(review)
admin.site.register(quiz)